# Make all the top-level functions in the module available
# via direct qualified reference whenever the module is
# imported.
from richreports.richreports import *

##eof