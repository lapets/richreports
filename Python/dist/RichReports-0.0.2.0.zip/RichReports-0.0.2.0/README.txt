richreports.py
==============

Library for building annotated abstract syntax trees and rendering them as interactive HTML reports.

   A library that supports the manual and automated assembly of
   modules for building interactive HTML reports consisting of
   abstract syntax trees as concrete syntax annotated with the
   results of static analysis and abstract interpretation algorithms.

   Web:     richreports.org
   Version: 0.0.2.0
